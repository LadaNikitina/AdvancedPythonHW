from setuptools import setup

setup(
    name = 'ldr_tex_table_image_generation',
    packages = ['tex_table_image_generation']
)